import Link from 'next/link'

interface HeroProps {
  onQuoteClick: () => void
}

export default function Hero({ onQuoteClick }: HeroProps) {
  return (
    <section className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-20">
      <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h1 className="text-5xl font-bold mb-4">
            Servicios Profesionales de Limpieza
          </h1>
          <p className="text-xl text-blue-100 mb-8">
            Transforma tus espacios con nuestro equipo experto. Cotizaciones rápidas y precios competitivos para tu hogar o negocio.
          </p>
          <div className="flex gap-4">
            <Link
              href="/quotation"
              className="bg-white text-blue-600 px-8 py-3 rounded-lg font-bold hover:bg-gray-100 transition inline-block"
            >
              Solicitar Cotización
            </Link>
            <button
              onClick={onQuoteClick}
              className="border-2 border-white text-white px-8 py-3 rounded-lg font-bold hover:bg-blue-700 transition"
            >
              Conocer Más
            </button>
          </div>
        </div>
        <div className="bg-blue-500 rounded-lg p-8 text-center">
          <div className="text-6xl mb-4">🧹</div>
          <p className="text-lg font-semibold">Limpieza Profesional desde 2024</p>
        </div>
      </div>
    </section>
  )
}