import Link from 'next/link'

export default function Services() {
  const services = [
    {
      icon: '🏠',
      title: 'Limpieza Residencial',
      description: 'Mantén tu hogar impecable con nuestro servicio especializado'
    },
    {
      icon: '🏢',
      title: 'Limpieza Comercial',
      description: 'Espacios de trabajo limpios y profesionales para tu empresa'
    },
    {
      icon: '🧼',
      title: 'Desinfección Profunda',
      description: 'Elimina bacterias y virus con nuestros tratamientos especializados'
    },
    {
      icon: '🪟',
      title: 'Limpieza de Cristales',
      description: 'Cristales impecables que dejan entrar la luz natural'
    },
  ]

  return (
    <section id="services" className="py-16 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12 text-gray-900">
          Nuestros Servicios
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg hover:scale-105 transition transform"
            >
              <div className="text-4xl mb-4">{service.icon}</div>
              <h3 className="text-xl font-bold mb-2 text-gray-900">{service.title}</h3>
              <p className="text-gray-600 mb-4">{service.description}</p>
              <Link
                href="/quotation"
                className="text-blue-600 font-semibold hover:text-blue-700"
              >
                Cotizar →
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}