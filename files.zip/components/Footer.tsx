export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 py-12">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="text-white font-bold text-lg mb-4">proKleen Cuu</h3>
            <p>Servicios profesionales de limpieza para transformar tus espacios.</p>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4">Enlaces Rápidos</h4>
            <ul className="space-y-2">
              <li><a href="/" className="hover:text-white transition">Inicio</a></li>
              <li><a href="/#services" className="hover:text-white transition">Servicios</a></li>
              <li><a href="/quotation" className="hover:text-white transition">Cotizador</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4">Contacto</h4>
            <p>📧 info@proKleencuu.com</p>
            <p>📱 +57 (XXX) XXX-XXXX</p>
            <p>📍 Colombia</p>
          </div>
        </div>
        <div className="border-t border-gray-700 pt-8 text-center">
          <p>&copy; 2024 proKleen Cuu. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  )
}