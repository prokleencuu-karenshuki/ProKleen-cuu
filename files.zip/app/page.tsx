'use client'

import Hero from '@/components/Hero'
import Services from '@/components/Services'
import { useState } from 'react'
import Link from 'next/link'

export default function Home() {
  const [showQuickQuote, setShowQuickQuote] = useState(false)

  return (
    <div>
      <Hero onQuoteClick={() => setShowQuickQuote(true)} />
      <Services />

      {/* Sección de Características */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-12 text-gray-900">
            ¿Por qué elegir proKleen Cuu?
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition">
              <div className="text-4xl mb-4">✓</div>
              <h3 className="text-xl font-bold mb-2">Personal Capacitado</h3>
              <p className="text-gray-600">Equipo profesional y experimentado en todas las áreas de limpieza</p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition">
              <div className="text-4xl mb-4">⏱️</div>
              <h3 className="text-xl font-bold mb-2">Respuesta Rápida</h3>
              <p className="text-gray-600">Cotizamos en menos de 24 horas y nos adaptamos a tu disponibilidad</p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition">
              <div className="text-4xl mb-4">💰</div>
              <h3 className="text-xl font-bold mb-2">Precios Competitivos</h3>
              <p className="text-gray-600">Obtén las mejores tarifas sin comprometer la calidad del servicio</p>
            </div>
          </div>
        </div>
      </section>

      {/* Llamada a la Acción */}
      <section className="py-16 bg-blue-600">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            ¿Listo para contratar nuestros servicios?
          </h2>
          <p className="text-blue-100 mb-8 text-lg">
            Solicita una cotización sin compromiso. Nos comunicaremos en las próximas 24 horas.
          </p>
          <div className="flex gap-4 justify-center">
            <Link href="/quotation" className="bg-white text-blue-600 px-8 py-3 rounded-lg font-bold hover:bg-gray-100 transition">
              Solicitar Cotización
            </Link>
            <button className="border-2 border-white text-white px-8 py-3 rounded-lg font-bold hover:bg-blue-700 transition">
              Contactar Directamente
            </button>
          </div>
        </div>
      </section>
    </div>
  )
}