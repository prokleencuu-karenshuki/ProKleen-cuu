'use client'

import { useState } from 'react'

const SERVICES = [
  { id: 1, name: 'Limpieza Residencial', price: 50, unit: 'hora' },
  { id: 2, name: 'Limpieza Comercial', price: 80, unit: 'hora' },
  { id: 3, name: 'Desinfección', price: 100, unit: 'sesión' },
  { id: 4, name: 'Limpieza de Alfombras', price: 45, unit: 'metro cuadrado' },
  { id: 5, name: 'Limpieza de Cristales', price: 35, unit: 'metro cuadrado' },
  { id: 6, name: 'Limpieza Post-Construcción', price: 120, unit: 'sesión' },
]

export default function QuotationPage() {
  const [selectedServices, setSelectedServices] = useState<any[]>([])
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    date: '',
    notes: '',
  })
  const [submitted, setSubmitted] = useState(false)

  const addService = (service: any) => {
    setSelectedServices([...selectedServices, { ...service, quantity: 1 }])
  }

  const removeService = (index: number) => {
    setSelectedServices(selectedServices.filter((_, i) => i !== index))
  }

  const updateQuantity = (index: number, quantity: number) => {
    const updated = [...selectedServices]
    updated[index].quantity = Math.max(1, quantity)
    setSelectedServices(updated)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
  }

  const calculateTotal = () => {
    return selectedServices.reduce((total, service) => {
      return total + (service.price * service.quantity)
    }, 0)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const quotation = {
      ...formData,
      services: selectedServices,
      total: calculateTotal(),
      date: new Date().toLocaleString('es-CO'),
    }

    console.log('Cotización:', quotation)

    // Aquí puedes enviar a un endpoint
    try {
      const response = await fetch('/api/quotations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(quotation),
      })

      if (response.ok) {
        setSubmitted(true)
        setFormData({ name: '', email: '', phone: '', address: '', date: '', notes: '' })
        setSelectedServices([])
        setTimeout(() => setSubmitted(false), 5000)
      }
    } catch (error) {
      console.error('Error:', error)
    }
  }

  const total = calculateTotal()

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12">
      <div className="max-w-6xl mx-auto px-4">
        <h1 className="text-4xl font-bold text-center mb-2 text-gray-900">
          Genera tu Cotización
        </h1>
        <p className="text-center text-gray-600 mb-12">
          Selecciona los servicios que necesitas y completa tu información
        </p>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Columna Izquierda - Servicios */}
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-bold mb-4 text-gray-900">
              Nuestros Servicios
            </h2>
            <div className="space-y-3">
              {SERVICES.map((service) => (
                <div key={service.id} className="border border-gray-200 p-4 rounded-lg hover:border-blue-500 transition">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-bold text-gray-900">{service.name}</h3>
                      <p className="text-sm text-gray-600">${service.price} por {service.unit}</p>
                    </div>
                    <button
                      onClick={() => addService(service)}
                      className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700 transition"
                    >
                      + Agregar
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Columna Derecha - Carrito y Formulario */}
          <div className="space-y-6">
            {/* Resumen de Cotización */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-2xl font-bold mb-4 text-gray-900">
                Tu Cotización
              </h2>
              {selectedServices.length === 0 ? (
                <p className="text-gray-500 text-center py-8">
                  Selecciona servicios para comenzar
                </p>
              ) : (
                <div className="space-y-3">
                  {selectedServices.map((service, index) => (
                    <div key={index} className="flex items-center justify-between border-b pb-2">
                      <div className="flex-1">
                        <p className="font-semibold text-gray-900">{service.name}</p>
                        <p className="text-sm text-gray-600">${service.price} × {service.unit}</p>
                      </div>
                      <input
                        type="number"
                        min="1"
                        value={service.quantity}
                        onChange={(e) => updateQuantity(index, parseInt(e.target.value))}
                        className="w-12 border border-gray-300 rounded px-2 py-1 text-center"
                      />
                      <p className="font-bold text-gray-900 w-20 text-right">
                        ${(service.price * service.quantity).toFixed(0)}
                      </p>
                      <button
                        onClick={() => removeService(index)}
                        className="text-red-600 hover:text-red-800 ml-2"
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                  <div className="border-t-2 pt-3 mt-4">
                    <div className="flex justify-between items-center">
                      <span className="text-xl font-bold text-gray-900">TOTAL:</span>
                      <span className="text-3xl font-bold text-blue-600">${total.toFixed(0)}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Formulario de Contacto */}
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-lg p-6 space-y-4">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Tu Información</h2>

              <input
                type="text"
                name="name"
                placeholder="Nombre completo *"
                value={formData.name}
                onChange={handleInputChange}
                required
                className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:border-blue-500"
              />

              <input
                type="email"
                name="email"
                placeholder="Correo electrónico *"
                value={formData.email}
                onChange={handleInputChange}
                required
                className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:border-blue-500"
              />

              <input
                type="tel"
                name="phone"
                placeholder="Teléfono *"
                value={formData.phone}
                onChange={handleInputChange}
                required
                className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:border-blue-500"
              />

              <input
                type="text"
                name="address"
                placeholder="Dirección *"
                value={formData.address}
                onChange={handleInputChange}
                required
                className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:border-blue-500"
              />

              <input
                type="date"
                name="date"
                value={formData.date}
                onChange={handleInputChange}
                className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:border-blue-500"
              />

              <textarea
                name="notes"
                placeholder="Notas adicionales (opcional)"
                value={formData.notes}
                onChange={handleInputChange}
                rows={3}
                className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:border-blue-500"
              />

              <button
                type="submit"
                disabled={selectedServices.length === 0}
                className="w-full bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700 transition disabled:bg-gray-400"
              >
                Enviar Cotización
              </button>

              {submitted && (
                <div className="bg-green-50 border border-green-200 text-green-800 p-4 rounded-lg">
                  ✓ Cotización enviada exitosamente. Te contactaremos pronto.
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}